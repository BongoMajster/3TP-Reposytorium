<?php

define ('PASS_SALT', 'xyz234@');